import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Main2014302580373 {

	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
		try
		{
			HttpRequest2014302580373 mainResponse = HttpRequest2014302580373.get("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai%20Xin%20Ping");
			mainResponse.receive(new File("./index.html"));
			System.out.println("HTML is created.");
			
			File inputHTML = new File("./index.html");
			Document doc = Jsoup.parse(inputHTML, "UTF-8");
			Elements nameE = doc.select("h3[class]:matches([\u4e00-\u9fa5]{3})");
			String nameS = nameE.text();
			Elements infoE = doc.select("p:matches(\\d{11})");
			String infoS = infoE.text();	
			String[] everyInfoS = infoS.split(" ");
			
			FileOutputStream outputTXT = new FileOutputStream("./teacherInfo.txt");
			outputTXT.write("������".getBytes());
			outputTXT.write(nameS.getBytes());
			outputTXT.write("\n".getBytes());
			outputTXT.write("��飺".getBytes());
			for(int i=0; i<everyInfoS.length; i++)
			{
				outputTXT.write(everyInfoS[i].getBytes());
				if(i>1 && i%2==0)
				{
					outputTXT.write("\n".getBytes());
				}
			}
			outputTXT.close();
			System.out.println("TXT is created.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
